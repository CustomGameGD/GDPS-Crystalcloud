<?php
include "incl/profiles/updateGJAccSettings.php";
?>