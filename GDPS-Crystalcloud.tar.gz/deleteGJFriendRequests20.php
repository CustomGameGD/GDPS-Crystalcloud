<?php
include "incl/relationships/deleteGJFriendRequests.php";
?>