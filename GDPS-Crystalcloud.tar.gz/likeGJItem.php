<?php
include "incl/misc/likeGJItem.php";
?>